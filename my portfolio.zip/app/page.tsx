
import Image from "next/image";

export default function Home() {
  return (
    <main className="home-page">
      {/* نوبار */}
      <header className="navbar">
        <div className="navbar-logo">
          <Image
            src="/images/logo.svg"
            alt="لوگوی امید منصوری"
            width={150}
            height={50}
            priority
          />
        </div>

        <nav className="navbar-menu">
          <a href="#home">خانه</a>
          <a href="#about">درباره من</a>
          <a href="#projects">پروژه‌ها</a>
          <a href="#services">خدمات</a>
          <a href="#contact">تماس با من</a>
        </nav>

        <a href="#contact" className="consultation-button">
          مشاوره رایگان
        </a>
      </header>

      {/* بخش اصلی Hero */}
      <section className="hero-section" id="home">
        <div className="hero-content">
          <h1>
            طراحی تجربه‌هایی
            <br />
            برای ارتباط بهتر
          </h1>

          <p>
            به دنیای طراحی محصول دیجیتال خوش آمدی؛
            جایی که ایده‌ها به تجربه‌هایی ساده و کاربردی تبدیل می‌شوند.
          </p>

          <div className="hero-actions">
            <a href="#projects" className="cta-button">
              مشاهده پروژه‌ها
            </a>

            <a href="#contact" className="cta-button cta-button-outline">
              شروع همکاری
            </a>
          </div>
        </div>

        {/* جایگاه بنر اختصاصی؛ تصویر بعداً اضافه می‌شود */}
        <div
          className="hero-banner-placeholder"
          aria-label="جایگاه بنر اختصاصی"
        />
      </section>
    </main>
  );
}
